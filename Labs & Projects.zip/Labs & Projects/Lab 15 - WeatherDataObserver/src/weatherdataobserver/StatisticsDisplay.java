/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weatherdataobserver;

/**
 *
 * @author user10
 */
// which 2 interfaces does StatisticsDisplay implement??????????
public class StatisticsDisplay implements Observer, DisplayElement 
{
	private float maxTemp = 0.0f;
	private float minTemp = 200;
	private float tempSum= 0.0f;
	private int numReadings;
	private WeatherData weatherData;

	public StatisticsDisplay(WeatherData weatherData) 
        {
		this.weatherData = weatherData;
		// register with the weatherData object everytime a 
                // CurrentConditionsDisplay object is created????????????????
		// rememebr you pass in this object itself as a parameter to the register method.?????? 
                weatherData.registerObserver(this);
        }

	public void update(float temp, float humidity, float pressure) 
        {
            // set the instance variables based on the new data passed in here.
		this.tempSum += temp;
		this.numReadings++;

		if (temp > maxTemp) 
                {
			maxTemp = temp;
		}
 
		if (temp < minTemp) 
                {
			minTemp = temp;
		}
                
                // Now StatisticsDisplay needs to re-display its data????????????????????????????????
                display();
	}

	public void display() 
        {
		// display something sensible here ????????????????????
            System.out.println("Statistics Display");
            System.out.println("    Max Temp: " + maxTemp);
            System.out.println("    Min Temp: " + minTemp);
	}
}

