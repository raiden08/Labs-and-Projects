/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weatherdataobserver;

/**
 *
 * @author user10
 */
public interface Subject 
{
   // Subject has 3 methods. What are they???????????????
    public static void registerObserver()
    {
        
    }
    
    public static void removeObserver()
    {
        
    }
    
    public static void notifyObserver()
    {
        
    }
    
}
