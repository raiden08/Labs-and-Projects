/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weatherdataobserver;

/**
 *
 * @author user10
 */
public class WeatherDataObserver 
{

  public static void main(String[] args) 
  {
		WeatherData weatherData = new WeatherData();
	
		// Create currentDisplay as an object ???????????????
                CurrentConditionDisplay currentCondition = new CurrentConditionDisplay(weatherData);
		// Create statisticsDisplay ??????????????????
                StatisticsDisplay statisticsDisplay = new StatisticsDisplay(weatherData);
		// Create forecastDisplay ??????????????????
                ForecastDisplay forecastDisplay = new ForecastDisplay(weatherData);

                // Note you call setMeasurements() but never directly call display.
                // However all the observer objects call their display method.
                // Set your breakpoint at the line below and follow step by step through the
                // code use the debugger  - you need to do this for your sequence diagram. 
		weatherData.setMeasurements(26, 65, 30.4f);
                System.out.println(" ");
		weatherData.setMeasurements(30, 70, 29.2f);
                System.out.println(" ");
		weatherData.setMeasurements(5, 90, 29.2f);
                
               
	}
}
