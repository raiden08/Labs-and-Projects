
package weatherdataobserver;

/**
 *
 * @author Anne
 */
// which 2 interfaces does CurrentConditionsDisplay implement??????????
public class CurrentConditionDisplay implements Observer, DisplayElement 
{
	private float temperature;
	private float humidity;
	private Subject weatherData;
	
	public CurrentConditionDisplay(WeatherData weatherData) 
        {
		this.weatherData = weatherData;
                // register with the weatherData object everytime a 
                // CurrentConditionsDisplay object is created????????????????
		// rememebr you pass in this object itself as a parameter to the register method.
                weatherData.registerObserver(this);
        }
	
	public void update(float temperature, float humidity, float pressure) 
        {
		//update CurrentConditionsDisplay instance varaibles with the new values passed in???????????
                this.temperature = temperature;
                this.humidity = humidity;
                // call display()?????????????
                display();
	}
	
	public void display() 
        {
                // Display something sensible here.?????????????
            System.out.println("Current conditions: " + temperature + "C Degrees and "
            + humidity + "% humidity");
	}
}
