/**
 *
 * @author N00145782
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class WineryTableGateway 
{
    private static final String TABLE_NAME = "winery";
    private static final String COLUMN_WINERYID = "wineryID";
    private static final String COLUMN_WINERYNAME = "wineryName";
    private static final String COLUMN_ADDRESS = "address";
    private static final String COLUMN_CONTACTNAME = "contactName";
    private static final String COLUMN_CONTACTPHONE = "contactPhone";
    private static final String COLUMN_CONTACTEMAIL = "contactEmail";
    private static final String COLUMN_WEBSITE = "website";
    
    private Connection wryConnection;
    
    public WineryTableGateway (Connection connection)
    {
        wryConnection = connection;
    }
    
    public Winery insertWinery(String n, String a, String cn, int cp, String ce, String w) throws SQLException
    {
        Winery wry = null;
        
        String query;
        PreparedStatement stmt;
        int numRowsAffected;
        int id;
        
        query = "INSERT INTO " + TABLE_NAME + " (" +
                COLUMN_WINERYNAME + ", " +
                COLUMN_ADDRESS + ", " +
                COLUMN_CONTACTNAME + ", " +
                COLUMN_CONTACTPHONE + ", " +
                COLUMN_CONTACTEMAIL + ", " +
                COLUMN_WEBSITE  +
                ") VALUES (?, ?, ?, ?, ?, ?)";
        
        stmt = wryConnection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
        stmt.setString(1, n);
        stmt.setString(2, a);
        stmt.setString(3, cn);
        stmt.setInt(4, cp);
        stmt.setString(5, ce);
        stmt.setString(6, w);
        
         numRowsAffected = stmt.executeUpdate();
        if (numRowsAffected == 1)
        {
            ResultSet keys = stmt.getGeneratedKeys();
            keys.next();
            
            id = keys.getInt(1);
            
            wry = new Winery(id, n, a, cn, cp, ce, w);
        }
      return wry;
    }
    
    public List<Winery> getWinery() throws SQLException
    {
        String query;
        Statement stmt;
        ResultSet rs;
        List<Winery> winery;
        
        String name, address, contactName, contactEmail, website;
        int id, contactPhone;
        
        
        Winery wry;
        
        query = "SELECT * FROM " + TABLE_NAME;
        stmt = this.wryConnection.createStatement();
        rs = stmt.executeQuery(query);
        
        winery = new ArrayList<Winery>();
        while (rs.next())
        {
            id = rs.getInt(COLUMN_WINERYID);
            name = rs.getString(COLUMN_WINERYNAME);
            address = rs.getString(COLUMN_ADDRESS);
            contactName = rs.getString(COLUMN_CONTACTNAME);
            contactPhone = rs.getInt(COLUMN_CONTACTPHONE);
            contactEmail = rs.getString(COLUMN_CONTACTEMAIL);
            website = rs.getString(COLUMN_WEBSITE);
            
            wry = new Winery(id, name, address, contactName, contactPhone, contactEmail, website);
            winery.add(wry);
        }
        
        return winery;
    }
    
    public boolean removeWinery(int wineryID) throws SQLException 
    {
        
        String query;
        PreparedStatement stmt = null; 
        int numRowsAffected;
        
        query = "DELETE FROM " + TABLE_NAME + " WHERE " + COLUMN_WINERYID + " = ?";
        
        stmt = wryConnection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
        stmt.setInt(1, wineryID);
        
        numRowsAffected = stmt.executeUpdate(); 
      
        return (numRowsAffected == 1);
    }
    
    boolean updateWinery(Winery wry) throws SQLException 
    {
        String query;                   
        PreparedStatement stmt;         
        int numRowsAffected;

        query = "UPDATE " + TABLE_NAME + " SET " +
                COLUMN_WINERYNAME + " = ?, " +
                COLUMN_ADDRESS + " = ?, " +
                COLUMN_CONTACTNAME + " = ? " + 
                COLUMN_CONTACTPHONE + " = ? " +
                COLUMN_CONTACTEMAIL + " = ? " +
                COLUMN_WEBSITE + " = ? " +
                " WHERE " + COLUMN_WINERYID + " = ?";

        stmt = wryConnection.prepareStatement(query);
        stmt.setString(1, wry.getWineryName());
        stmt.setString(2, wry.getAddress());
        stmt.setString(3, wry.getContactName());
        stmt.setInt(4, wry.getContactNumber());
        stmt.setString(5, wry.getEmail());
        stmt.setString(6, wry.getWebAddress());
        stmt.setInt(7, wry.getWineryID());
        
        numRowsAffected = stmt.executeUpdate();

        return (numRowsAffected == 1);
    }    
}
