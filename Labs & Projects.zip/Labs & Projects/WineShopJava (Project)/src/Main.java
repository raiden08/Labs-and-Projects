/**
 *
 * @author N00145782
 */

import java.util.*;

public class Main 
{
    
    public static void main(String[] args) 
    {
        Scanner keyboard = new Scanner(System.in);
        
        Model model = Model.connect();
        
        Wine w;
        Winery wry;
        Grape g;
        
        int opt;
        do {
            System.out.println("---------------------------------------------");
            System.out.println("1. Add a Wine");
            System.out.println("2. Delete a Wine");
            System.out.println("3. View all Wine");
            System.out.println("4. Edit a Wine");
            System.out.println("---------------------------------------------");
            System.out.println("5. Add a Winery");
            System.out.println("6. Delete a Winery");
            System.out.println("7. View all Winery");
            System.out.println("8. Edit a Winery");
            System.out.println("---------------------------------------------");
            System.out.println("9. Add a Grape");
            System.out.println("10. Delete a Grape");
            System.out.println("11. View all Grape");
            System.out.println("12. Edit a Grape");
            System.out.println("0. Exit");
            
            System.out.println("Enter option: ");
            String line = keyboard.nextLine();
            opt = Integer.parseInt(line);
            
            System.out.println("You chose option " + opt);
            switch (opt) 
            {
                case 1: 
                {
                    System.out.println("Add a Wine");
                    w = addWine(keyboard);
                    model.addWine(w);
                    break;  
                }
                case 2: 
                {
                    System.out.println("Delete a Wine");
                    deleteWine(keyboard, model);
                    
                    break;
                }
                case 3: 
                {
                    System.out.println("View all Wine");
                    viewWine(model);
                    break;
                }
                
                 case 4: 
                {
                    System.out.println("Edit a Wine");
                    updateWine(keyboard, model);
                    break;  
                }
                
            //----------------------------------------------------------------- 
               
                
                case 5: 
                {
                    System.out.println("Add a Winery");
                    wry = addWinery(keyboard);
                    model.addWinery(wry);
                    break;  
                }
                case 6: 
                {
                    System.out.println("Delete a Winery");
                    deleteWinery(keyboard, model);
                    
                    break;
                }
                case 7: 
                {
                    System.out.println("View all Winery");
                    viewWinery(model);
                    break;
                }
                
                 case 8: 
                {
                    System.out.println("Edit a Winery");
                    updateWinery(keyboard, model);
                    break;  
                }
                
            //------------------------------------------------------------------ 
                case 9: 
                {
                    System.out.println("Add a Grape");
                    g = addGrape(keyboard);
                    model.addGrape(g);
                    break;  
                }
                case 10: 
                {
                    System.out.println("Delete a Grape");
                    deleteGrape(keyboard, model);
                    
                    break;
                }
                case 11: 
                {
                    System.out.println("View all Grape");
                    viewGrape(model);
                    break;
                }
                
                 case 12: 
                {
                    System.out.println("Edit a Grape");
                    updateGrape(keyboard, model);
                    break;  
                }
            }
        }
        
        while(opt != 0);
        System.out.println("Exit");
    }
    
    private static Wine addWine(Scanner keyb) 
    {
        String wineName;
        int year, wineID;
        double temperature;
        String line;
        
        line = getString(keyb, "Enter Wine ID: ");
        wineID = Integer.parseInt(line);
        wineName = getString(keyb, "Enter Wine Name: ");
        line = getString(keyb, "Enter Year: ");
        year = Integer.parseInt(line);
        line = getString(keyb, "Enter Temperature: ");
        temperature = Double.parseDouble(line);
        
        
        Wine w = new Wine(wineID, wineName, year, temperature);
        
        return w;
    }
    
    private static Winery addWinery(Scanner keyb) 
    {
        String wineryName;
        String address;
        String contactName;
        int contactNumber, wineryID;
        String email;
        String webAddress;
        String line;
        
        line = getString(keyb, "Enter Winery ID: ");
        wineryID = Integer.parseInt(line);
        wineryName = getString(keyb, "Enter Winery Name: ");
        address = getString(keyb, "Enter Winery Address: ");
        contactName = getString(keyb, "Enter Contact Name: ");
        line = getString(keyb, "Enter Contact Number: ");
        contactNumber = Integer.parseInt(line);
        email = getString(keyb, "Enter Contact Email Address: ");
        webAddress = getString(keyb, "Enter Winery Web Address: ");
        
        Winery wry = new Winery(wineryID, wineryName, address, contactName, contactNumber, email, webAddress);
        
        return wry;
    }
     
    private static Grape addGrape(Scanner keyb) 
    {
        String grapeType;
        String country;
        String desc;
        int grapeID;
        String line;
        
        line = getString(keyb, "Enter Grape ID: ");
        grapeID = Integer.parseInt(line);
        grapeType = getString(keyb, "Enter Grape Type: ");
        country = getString(keyb, "Enter Country of Origin");
        desc = getString(keyb, "Enter Description");
        
        Grape g = new Grape(grapeID, grapeType, country, desc);
        
        return g;
    }
    
    private static void updateWine(Scanner kb, Model m) 
    {
        System.out.print("Enter the ID of the wine you want to edit: ");
        int wineID = Integer.parseInt(kb.nextLine());
        Wine w;

        w = m.findWine(wineID);
        if (w != null) 
        {
            editWineDetails(kb, w);
            if (m.updateWine(w)) 
            {
                System.out.println("Wine Details updated");
            }
            else 
            {
                System.out.println("Wine Details not updated");
            }
        }
        else 
        {
            System.out.println("Wine not found");
        }
    }
    
    private static void editWineDetails(Scanner keyb, Wine w) 
    {
        String wineName;
        int year;
        double temp;
        String line2, line3;

        
        wineName = getString(keyb, "Enter new Wine Name [" +  w.getWineName() + "]: "); 
        line2 = getString(keyb, "Enter new Year [" +  w.getYear() + "]: ");
        line3 = getString(keyb, "Enter new Temperature [" +  w.getTemp() + "]: ");
       

        if (wineName.length() != 0) 
        {
            w.setWineName(wineName);
        }   
        
        if (line2.length() != 0) 
        {
            year = Integer.parseInt(line2);
            w.setYear(year);
        }
        if (line3.length() != 0) 
        {
            temp = Double.parseDouble(line3);
            w.setTemp(temp);
        }
        
    }
    
    private static void updateWinery(Scanner kb, Model m) 
    {
        System.out.print("Enter the ID of the winery you want to edit: ");
        int wineryID = Integer.parseInt(kb.nextLine());
        Winery wry;

        wry = m.findWinery(wineryID);
        if (wry != null) 
        {
            editWineryDetails(kb, wry);
            if (m.updateWinery(wry)) 
            {
                System.out.println("Winery Details updated");
            }
            else 
            {
                System.out.println("Winery Details not updated");
            }
        }
        else 
        {
            System.out.println("Winery not found");
        }
    }
    
    private static void editWineryDetails(Scanner keyb, Winery wry) 
    {
        String wineryName, address, contactName, email, website;
        int phone;
        String line;

        
        wineryName = getString(keyb, "Enter new Winery Name [" +  wry.getWineryName() + "]: "); 
        address = getString(keyb, "Enter new Winery Address [" +  wry.getAddress() + "]: ");
        contactName = getString(keyb, "Enter new Contact Name [" +  wry.getContactName() + "]: ");
        line = getString(keyb, "Enter new Contact Number [" +  wry.getContactNumber() + "]: ");
        email = getString(keyb, "Enter new Contact Email [" +  wry.getEmail() + "]: ");
        website = getString(keyb, "Enter new Winery Website [" +  wry.getWebAddress() + "]: ");
       

        if (wineryName.length() != 0) 
        {
            wry.setWineryName(wineryName);
        }
        if (address.length() != 0) 
        {
            wry.setAddress(address);
        }
        if (contactName.length() != 0) 
        {
            wry.setContactName(contactName);
        }  
        if (line.length() != 0) 
        {
            phone = Integer.parseInt(line);
            wry.setContactNumber(phone);
        }
        if (email.length() != 0) 
        {
            wry.setEmail(email);
        }  
        if (website.length() != 0) 
        {
            wry.setWebAddress(website);
        }  
        
    }
    
    private static void updateGrape(Scanner kb, Model m) 
    {
        System.out.print("Enter the ID of the Grape you want to edit: ");
        int grapeID = Integer.parseInt(kb.nextLine());
        Grape g;

        g = m.findGrape(grapeID);
        if (g != null) 
        {
            editGrapeDetails(kb, g);
            if (m.updateGrape(g)) 
            {
                System.out.println("Grape Details updated");
            }
            else 
            {
                System.out.println("Grape Details not updated");
            }
        }
        else 
        {
            System.out.println("Grape not found");
        }
    }
    
    private static void editGrapeDetails(Scanner keyb, Grape g) 
    {
        String grapeType, country, desc;
        
       grapeType = getString(keyb, "Enter new Grape Type [" +  g.getGrapeType() + "]: "); 
       country = getString(keyb, "Enter new Country [" +  g.getCountry() + "]: ");
       desc = getString(keyb, "Enter new Description [" +  g.getDescription() + "]: ");
       

        if (grapeType.length() != 0) 
        {
            g.setGrapeType(grapeType);
        }
        if (country.length() != 0) 
        {
            g.setCountry(country);
        }
        if (desc.length() != 0) 
        {
            g.setDescription(desc);
        }  
        
        
        
    }
        
    private static void deleteWine(Scanner kb, Model m) 
    {
        System.out.print("Enter the ID of the wine you want to delete:");
        int wineID = Integer.parseInt(kb.nextLine());
        Wine w;

        w = m.findWine(wineID);
        if (w != null) 
        {
            if (m.removeWine(w)) 
            {
                System.out.println("Wine deleted");
            }
            else 
            {
                System.out.println("Wine not deleted");
            }
        }
        else 
        {
            System.out.println("Wine not found");
        }
    }
    
    
    
    private static void deleteWinery(Scanner kb, Model m) 
    {
        System.out.print("Enter the Winery ID you want to delete: ");
        int wineryID = Integer.parseInt(kb.nextLine());
        Winery wry;

        wry = m.findWinery(wineryID);
        if (wry != null) 
        {
            if (m.removeWinery(wry)) 
            {
                System.out.println("Winery deleted");
            }
            else 
            {
                System.out.println("Winery not deleted");
            }
        }
        else 
        {
            System.out.println("Winery not found");
        }
    }
    
    private static void deleteGrape(Scanner kb, Model m) 
    {
        System.out.print("Enter the Grape ID you want to delete:");
        int grapeID = Integer.parseInt(kb.nextLine());
        Grape g;

        g = m.findGrape(grapeID);
        if (g != null) 
        {
            if (m.removeGrape(g)) 
            {
                System.out.println("Grape deleted");
            }
            else 
            {
                System.out.println("Grape not deleted");
            }
        }
        else 
        {
            System.out.println("Grape not found");
        }
    }
    
    private static void viewWine(Model model) 
    {
        List<Wine> Wine = model.getWine();
        for (Wine w1 : Wine) 
        {
            System.out.println("---------------------------------------------");
            System.out.println("Wine ID: " + w1.getWineID());
            System.out.println("Wine Name: " + w1.getWineName());
            System.out.println("Year: " + w1.getYear());
            System.out.println("Ideal Serving Temperature: " + w1.getTemp());
            System.out.println("---------------------------------------------");
        }
    }
    
    private static void viewWinery(Model model) 
    {
        List<Winery> Winery = model.getWinery();
        for (Winery wry1 : Winery) 
        {
            System.out.println("Winery ID: " + wry1.getWineryID());
            System.out.println("Winery Name: " + wry1.getWineryName());
            System.out.println("Address: " + wry1.getAddress());
            System.out.println("Contact Name: " + wry1.getContactName());
            System.out.println("Contact Phone Number: " + wry1.getContactNumber());
            System.out.println("Email: " + wry1.getEmail());
            System.out.println("Website Address: " + wry1.getWebAddress());
        }
    }
    
    private static void viewGrape(Model model) 
    {
        List<Grape> Grape = model.getGrape();
        for (Grape g1 : Grape) 
        {
            System.out.println("Grape ID: " + g1.getGrapeID());
            System.out.println("Grape Type: " + g1.getGrapeType());
            System.out.println("Country of Origin: " + g1.getCountry());
            System.out.println("Grape Description: " + g1.getDescription());
        }
    }
    
    private static String getString(Scanner keyboard, String prompt) 
    {
        System.out.print(prompt);
        return keyboard.nextLine();
    }
    
}
