/**
 *
 * @author N00145782
 */

import java.util.*;

public class Wine 
{
    private int wineID;
    private String wineName;
    private int year;
    private double temp;
    
    public Wine(int newID, String newName, int newYear, double newTemp)
    {
        this.wineID = newID;
        this.wineName = newName;
        this.year = newYear;
        this.temp = newTemp;
    }

    public int getWineID() 
    {
        return wineID;
    }

    public void setWineID(int wineID) 
    {
        this.wineID = wineID;
    }
    
    public String getWineName() 
    {
        return wineName;
    }

    public void setWineName(String wineName) 
    {
        this.wineName = wineName;
    }

    public int getYear() 
    {
        return year;
    }

    public void setYear(int year) 
    {
        this.year = year;
    }

    public double getTemp() 
    {
        return temp;
    }

    public void setTemp(double temperature) 
    {
        this.temp = temperature;
    }   
}