/**
 *
 * @author N00145782
 */

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Model 
{
    private static Model instance = null;
    
    private List<Wine> Wine;
    private List<Winery> Winery;
    private List<Grape> Grape;
    private WineTableGateway wineGateway;
    private GrapeTableGateway grapeGateway;
    private WineryTableGateway wineryGateway;

    
    
    public static Model connect()
    {
        if (instance == null) 
        {
            instance = new Model();
        }
        return instance;
    }
          
    public Model() 
    {
        try 
        { 
            Connection connect = DBConnection.getInstance();
            this.wineGateway = new WineTableGateway(connect);
            this.wineryGateway = new WineryTableGateway(connect);
            this.grapeGateway = new GrapeTableGateway(connect);
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
        }  
    }

    public List<Wine> getWine() 
    {
        try
        {
        Wine = wineGateway.getWine();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return Wine;
     
    }
    
    public List<Winery> getWinery() 
    {
        try
        {
        Winery = wineryGateway.getWinery();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return Winery;
    }
    
    public List<Grape> getGrape() 
    {
        try
        {
        Grape = grapeGateway.getGrape();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return Grape;
    }
    
    public boolean addWine(Wine w) 
    {
       boolean result = false;
       try 
       {
        this.wineGateway.insertWine(w.getWineName(), w.getYear(), w.getTemp());
        this.Wine.add(w);          
       } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
        }
       return result;
    }
    
    public boolean addWinery(Winery wry) 
    {
       boolean result = false;
       try 
       {
        this.wineryGateway.insertWinery(wry.getWineryName(), wry.getAddress(), wry.getContactName(), wry.getContactNumber(), wry.getEmail(), wry.getWebAddress());
        this.Winery.add(wry);          
       } 
       catch (SQLException ex) 
       {
        Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
       }
       return result;
    }
    
    public boolean addGrape(Grape g) 
    {
       boolean result = false;
       try 
       {
        this.grapeGateway.insertGrape(g.getGrapeType(), g.getCountry(), g.getDescription());
        this.Grape.add(g);          
       } 
       catch (SQLException ex) 
       {
        Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
       }
       return result;
    }
    
    boolean updateWine(Wine w) 
    {
        boolean updated = false;

        try 
        {
            updated = this.wineGateway.updateWine(w);
        }
        catch (SQLException ex) 
        {
            Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
        }

        return updated;
    }
    
    boolean updateWinery(Winery wry) 
    {
        boolean updated = false;

        try 
        {
            updated = this.wineryGateway.updateWinery(wry);
        }
        catch (SQLException ex) 
        {
            Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
        }

        return updated;
    }
    
    boolean updateGrape(Grape g) 
    {
        boolean updated = false;

        try 
        {
            updated = this.grapeGateway.updateGrape(g);
        }
        catch (SQLException ex) 
        {
            Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
        }

        return updated;
    }
    
    public boolean removeWine(Wine w) 
    {
       boolean removed = false;

        try {
            removed = this.wineGateway.removeWine(w.getWineID());
            if (removed) 
            {
                removed = this.Wine.remove(w);
            }
        }
        catch (SQLException ex) 
        {
            Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
        }

        return removed;
    }
    
    public boolean removeWinery(Winery wry) 
    {
        boolean removed = false;

        try {
            removed = this.wineryGateway.removeWinery(wry.getWineryID());
            if (removed) 
            {
                removed = this.Winery.remove(wry);
            }
        }
        catch (SQLException ex) 
        {
            Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
        }

        return removed;
    }
    
    public boolean removeGrape(Grape g) 
    {
        boolean removed = false;

        try {
            removed = this.grapeGateway.removeGrape(g.getGrapeID());
            if (removed) 
            {
                removed = this.Grape.remove(g);
            }
        }
        catch (SQLException ex) 
        {
            Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
        }

        return removed;
    }
    
    Wine findWine(int wineID) 
    {
        Wine w = null;
        int i = 0;
        boolean found = false;
        while (i < this.Wine.size() && !found) 
        {
            w = this.Wine.get(i);
            if (w.getWineID() == wineID) 
            {
                found = true;
            } 
            else 
            {
                i++;
            }
        }
        if (!found) 
        {
            w = null;
        }
        return w;
    }
    
    Winery findWinery(int wineryID) 
    {
        Winery wry = null;
        int i = 0;
        boolean found = false;
        while (i < this.Winery.size() && !found) 
        {
            wry = this.Winery.get(i);
            if (wry.getWineryID() == wineryID) 
            {
                found = true;
            } 
            else 
            {
                i++;
            }
        }
        if (!found) 
        {
            wry = null;
        }
        return wry;
    }
    
    Grape findGrape(int grapeID) 
    {
        Grape g = null;
        int i = 0;
        boolean found = false;
        while (i < this.Grape.size() && !found) 
        {
            g = this.Grape.get(i);
            if (g.getGrapeID() == grapeID) 
            {
                found = true;
            } 
            else 
            {
                i++;
            }
        }
        if (!found) 
        {
            g = null;
        }
        return g;
    }
       
}