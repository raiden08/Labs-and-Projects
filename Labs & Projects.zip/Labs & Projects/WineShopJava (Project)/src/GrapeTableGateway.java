/**
 *
 * @author N00145782
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class GrapeTableGateway 
{
    private static final String TABLE_NAME = "grapes";
    private static final String COLUMN_GRAPEID = "grapeID";
    private static final String COLUMN_TYPE = "grapeType";
    private static final String COLUMN_COUNTRY = "country";
    private static final String COLUMN_DESCRIPTION = "description";
    
    private Connection gConnection;
    
    public GrapeTableGateway (Connection connection)
    {
        gConnection = connection;
    }
    
    public Grape insertGrape(String t, String c, String d) throws SQLException
    {
        Grape g = null;
        
        String query;
        PreparedStatement stmt;
        int numRowsAffected;
        int id;
        
        query = "INSERT INTO " + TABLE_NAME + " (" +
                COLUMN_TYPE + ", " +
                COLUMN_COUNTRY + ", " +
                COLUMN_DESCRIPTION  +
                ") VALUES (?, ?, ?)";
        
        stmt = gConnection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
        stmt.setString(1, t);
        stmt.setString(2, c);
        stmt.setString(3, d);
        
         numRowsAffected = stmt.executeUpdate();
        if (numRowsAffected == 1)
        {
            ResultSet keys = stmt.getGeneratedKeys();
            keys.next();
            
            id = keys.getInt(1);
            
            g = new Grape(id, t, c, d);
        }
      return g;
    }
    
   public List<Grape> getGrape() throws SQLException
   {
        String query;
        Statement stmt;
        ResultSet rs;
        List<Grape> grape;
        
        String grapeType, country, desc;
        int id;
        
        
        Grape g;
        
        query = "SELECT * FROM " + TABLE_NAME;
        stmt = this.gConnection.createStatement();
        rs = stmt.executeQuery(query);
        
        grape = new ArrayList<Grape>();
        while (rs.next())
        {
            id = rs.getInt(COLUMN_GRAPEID);
            grapeType = rs.getString(COLUMN_TYPE);
            country = rs.getString(COLUMN_COUNTRY);
            desc = rs.getString(COLUMN_DESCRIPTION);
            
            g = new Grape(id, grapeType, country, desc);
            grape.add(g);
        }
        
        return grape;
   }
    
   public boolean removeGrape(int grapeID) throws SQLException 
   {
        
        String query;
        PreparedStatement stmt = null; 
        int numRowsAffected;
        
        query = "DELETE FROM " + TABLE_NAME + " WHERE " + COLUMN_GRAPEID + " = ?";
        
        stmt = gConnection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
        stmt.setInt(1, grapeID);
        
        numRowsAffected = stmt.executeUpdate(); 
      
        return (numRowsAffected == 1);
   }
   
   boolean updateGrape(Grape g) throws SQLException 
   {
        String query;                   
        PreparedStatement stmt;         
        int numRowsAffected;

        query = "UPDATE " + TABLE_NAME + " SET " +
                COLUMN_TYPE + " = ?, " +
                COLUMN_COUNTRY + " = ?, " +
                COLUMN_DESCRIPTION + " = ? " + 
                " WHERE " + COLUMN_GRAPEID + " = ?";

        stmt = gConnection.prepareStatement(query);
        stmt.setString(1, g.getGrapeType());
        stmt.setString(2, g.getCountry());
        stmt.setString(3, g.getDescription());
        stmt.setInt(4, g.getGrapeID());
        
        numRowsAffected = stmt.executeUpdate();

        return (numRowsAffected == 1);
   }
   
}