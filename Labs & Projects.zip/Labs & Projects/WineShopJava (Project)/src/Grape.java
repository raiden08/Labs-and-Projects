/**
 *
 * @author N00145782
 */

import java.util.*;

public class Grape 
{
    private int grapeID;
    private String grapeType;
    private String country;
    private String description;

    public Grape(int newGrapeID, String grapeType, String country, String description) 
    {
        this.grapeID = newGrapeID;
        this.grapeType = grapeType;
        this.country = country;
        this.description = description;
    }

    public int getGrapeID() {
        return grapeID;
    }

    public void setGrapeID(int grapeID) 
    {
        this.grapeID = grapeID;
    }
    
    public String getGrapeType() 
    {
        return grapeType;
    }

    public void setGrapeType(String newGrapeType) 
    {
        this.grapeType = newGrapeType;
    }

    public String getCountry() 
    {
        return country;
    }

    public void setCountry(String newCountry) 
    {
        this.country = newCountry;
    }

    public String getDescription() 
    {
        return description;
    }

    public void setDescription(String newDescription) 
    {
        this.description = newDescription;
    }    
}