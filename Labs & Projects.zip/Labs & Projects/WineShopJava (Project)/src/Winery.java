/**
 *
 * @author N00145782
 */

import java.util.*;

public class Winery 
{
    private int wineryID;
    private String wineryName;
    private String address;
    private String contactName;
    private int contactNumber;
    private String email;
    private String webAddress;
    
    public Winery(int newID, String newName, String newAddress, String newcName, int newpNumber, String neweAddress, String newwAddress)
    {
        this.wineryID = newID;
        this.wineryName = newName;
        this.address = newAddress;
        this.contactName = newcName;
        this.contactNumber = newpNumber;
        this.email = neweAddress;
        this.webAddress = newwAddress;
    }

    public int getWineryID() 
    {
        return wineryID;
    }

    public void setWineryID(int wineryID) 
    {
        this.wineryID = wineryID;
    }

    public String getWineryName() 
    {
        return wineryName;
    }

    public void setWineryName(String wineryName) 
    {
        this.wineryName = wineryName;
    }

    public String getAddress() 
    {
        return address;
    }

    public void setAddress(String address) 
    {
        this.address = address;
    }

    public String getContactName() 
    {
        return contactName;
    }

    public void setContactName(String contactName) 
    {
        this.contactName = contactName;
    }

    public int getContactNumber() 
    {
        return contactNumber;
    }

    public void setContactNumber(int contactNumber) 
    {
        this.contactNumber = contactNumber;
    }

    public String getEmail() 
    {
        return email;
    }

    public void setEmail(String email) 
    {
        this.email = email;
    }

    public String getWebAddress() 
    {
        return webAddress;
    }

    public void setWebAddress(String webAddress) 
    {
        this.webAddress = webAddress;
    }
    
    
   
}
