/**
 *
 * @author N00145782
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection 
{
    
    private static final String USERNAME = "N00145782";
    private static final String PASSWORD = "N00145782";  
    private static final String CONN_STRING = "jdbc:mysql://daneel/N00145782";
    private static Connection sConnection;
    
    
        public static Connection getInstance() throws SQLException
        {
            //Class.forName("com.mysql.jdbc.driver");
            
            sConnection = null;
            
            try 
            {
                sConnection = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
                System.out.println("Connected!");
            } 
            catch (SQLException e) 
            {
                System.err.println(e);
            }
            finally
            {
                if (sConnection != null) 
                {
                 //   sConnection.close();
                }
            }
            return sConnection;
        }
}