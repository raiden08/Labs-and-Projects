/**
 *
 * @author N00145782
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class WineTableGateway 
{
    private static final String TABLE_NAME = "wines";
    private static final String COLUMN_WINEID = "wineID";
    private static final String COLUMN_WINENAME = "wineName";
    private static final String COLUMN_YEAR = "year";
    private static final String COLUMN_SERVINGTEMP = "servingTemp";
    
    
    private Connection wConnection;
    
    public WineTableGateway (Connection connection)
    {
        wConnection = connection;
    }
   
    public Wine insertWine(String n, int y, double t) throws SQLException
    {
        Wine w = null;
        
        String query;
        PreparedStatement stmt;
        int numRowsAffected;
        int id;
        
        query = "INSERT INTO " + TABLE_NAME + " (" +
                COLUMN_WINENAME + ", " +
                COLUMN_YEAR + ", " +
                COLUMN_SERVINGTEMP + 
                ") VALUES (?, ?, ?)";
        
        stmt = wConnection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
        stmt.setString(1, n);
        stmt.setInt(2, y);
        stmt.setDouble(3, t);
        
        
        numRowsAffected = stmt.executeUpdate();
        if (numRowsAffected == 1)
        {
            ResultSet keys = stmt.getGeneratedKeys();
            keys.next();
            
            id = keys.getInt(1);
            
            w = new Wine(id, n, y, t);
        }
      return w;
    }
    
    public List<Wine> getWine() throws SQLException
    {
        String query;
        Statement stmt;
        ResultSet rs;
        List<Wine> wine;
        
        String name;
        int id, year;
        double temp;
        
        Wine w;
        
        query = "SELECT * FROM " + TABLE_NAME;
        stmt = this.wConnection.createStatement();
        rs = stmt.executeQuery(query);
        
        wine = new ArrayList<Wine>();
        while (rs.next())
        {
            id = rs.getInt(COLUMN_WINEID);
            name = rs.getString(COLUMN_WINENAME);
            year = rs.getInt(COLUMN_YEAR);
            temp = rs.getDouble(COLUMN_SERVINGTEMP);
            
            w = new Wine(id, name, year, temp);
            wine.add(w);
        }
        
        return wine;
    }
    
    public boolean removeWine(int wineID) throws SQLException 
    {
        
        String query;
        PreparedStatement stmt = null; 
        int numRowsAffected;
        
        query = "DELETE FROM " + TABLE_NAME + " WHERE " + COLUMN_WINEID + " = ?";
        
        stmt = wConnection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
        stmt.setInt(1, wineID);
        
        numRowsAffected = stmt.executeUpdate(); 
      
        return (numRowsAffected == 1);
    }
    
    boolean updateWine(Wine w) throws SQLException 
    {
        String query;                   
        PreparedStatement stmt;         
        int numRowsAffected;

        query = "UPDATE " + TABLE_NAME + " SET " +
                COLUMN_WINENAME + " = ?, " +
                COLUMN_YEAR + " = ?, " +
                COLUMN_SERVINGTEMP + " = ? " + 
                " WHERE " + COLUMN_WINEID + " = ?";

        stmt = wConnection.prepareStatement(query);
        stmt.setString(1, w.getWineName());
        stmt.setInt(2, w.getYear());
        stmt.setDouble(3, w.getTemp());
        stmt.setInt(4, w.getWineID());
        
        numRowsAffected = stmt.executeUpdate();

        return (numRowsAffected == 1);
    }
    
}