public class WeeklySalaryEmployee extends Employee 
{
    private double weeklySalary;

    public WeeklySalaryEmployee(String first, String last, String ssn, double weekly) {
        super(first, last, ssn);
        setWeeklySalary(weekly);
    }

    public double getWeeklySalary() 
    {
        return weeklySalary;
    }

    public void setWeeklySalary(double weeklySalary) 
    {
        this.weeklySalary = weeklySalary;
    }
    
    @Override
    public double getEarnings()
    {
        return getWeeklySalary();
    }
    
    @Override
    public String toString()
    {
        return String.format("");
    }
}
