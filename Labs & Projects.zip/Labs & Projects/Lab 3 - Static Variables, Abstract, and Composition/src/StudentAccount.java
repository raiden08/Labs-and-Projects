/**
 *
 * @author N00145782
 */
public class StudentAccount extends BankAccount
{   
    private int studentNo;

    public StudentAccount(String name, String line1, String line2, String line3, int accNo, double balance, int studentNo) 
    {
        super(name, line1, line2, line3, accNo, balance);
        this.studentNo = studentNo;
    }

    public int getStudentNo() 
    {
        return studentNo;
    }

    public void setStudentNo(int studentNo) 
    {
        this.studentNo = studentNo;
    }
    
}
