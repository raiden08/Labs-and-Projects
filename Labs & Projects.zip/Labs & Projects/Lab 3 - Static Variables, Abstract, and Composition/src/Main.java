/**
 *
 * @author N00145782
 */
public class Main 
{
    public static void main(String[] args)
    {
//        BankAccount b1 = new BankAccount();
       

        
        SavingsAccount s1 = new SavingsAccount("bob", "17 ", "fitz ", "park" , 58, 10000);
        SavingsAccount s2 = new SavingsAccount("frank", "14 ", "mulgrave ", "street" , 69, 5000);
        SavingsAccount s3 = new SavingsAccount("tristan", "17 ", "merrion ", "dublin" , 97, 10);
        System.out.println("Name - " + s1.getName());
        System.out.println("Address - " + s1.getAddress());
        System.out.println("Account Number - " + s1.getAccNo());
        System.out.println("Balance - " + s1.getBalance());
        
        s1.setAddress("clarinda ", "dun laoghaire ", "dublin");
        System.out.println("-----------------------------------");
        System.out.println("Name - " + s1.getName());
        System.out.println("Address - " + s1.getAddress());
        System.out.println("Account Number - " + s1.getAccNo());
        System.out.println("Balance - €" + s1.getBalance());
        
        StudentAccount st1 = new StudentAccount("Genesis", "Clarinda Manor ", "Dun Laoghaire ", "Dublin", 364165, 2500, 145782);
        System.out.println("-----------------------------------");
        System.out.println("Name - " + st1.getName());
        System.out.println("Address - " + st1.getAddress());
        System.out.println("Account Number - " + st1.getAccNo());
        System.out.println("Balance - €" + st1.getBalance());
        System.out.println("Student Number - N00" + st1.getStudentNo());
    }
}
