/**
 *
 * @author N00145782
 */
public abstract class BankAccount 
{
    private String name;
    private Address address;
    private int accNo;
    private double balance;

    public BankAccount(String name, String line1, String line2, String line3, int accNo, double balance) 
    {
        this.name = name;
        this.address = new Address(line1, line2, line3);
        this.accNo = accNo;
        this.balance = balance;
    }
    
    public String getName() 
    {
        return name;
    }

    public void setName(String name) 
    {
        this.name = name;
    }

    public String getAddress() 
    {
        return address.getStreet() + address.getTown() + address.getCity();
    }

    public void setAddress(String line1, String line2, String line3) 
    {
        this.address.setStreet(line1);
        this.address.setTown(line2);
        this.address.setCity(line3);
    }

    public int getAccNo() 
    {
        return accNo;
    }

    public void setAccNo(int accNo) 
    {
        this.accNo = accNo;
    }

    public double getBalance() 
    {
        return balance;
    }

    public void setBalance(double balance) 
    {
        this.balance = balance;
    }
    
    
}
