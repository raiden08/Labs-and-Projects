/**
 *
 * @author N00145782
 */
public class SavingsAccount extends BankAccount
{
   
    private static double interestRate = 0.75;

    public SavingsAccount(String name, String line1, String line2, String line3, int accNo, double balance) 
    {
        super(name, line1, line2, line3, accNo, balance);
//        this.interestRate = interestRate;
    }

    public static double getInterestRate() 
    {
        return interestRate;
    }

    public static void setInterestRate(double interestRate) 
    {
        SavingsAccount.interestRate = interestRate;
    }
    
    
    
}
