/**
 *
 * @author N00145782
 */
public class Address 
{
    private String Street;
    private String Town;
    private String City;

    public Address(String Street, String Town, String City) 
    {
        this.Street = Street;
        this.Town = Town;
        this.City = City;
    }
 
    public String getStreet() 
    {
        return Street;
    }

    public void setStreet(String Street) 
    {
        this.Street = Street;
    }

    public String getTown() 
    {
        return Town;
    }

    public void setTown(String Town) 
    {
        this.Town = Town;
    }

    public String getCity() 
    {
        return City;
    }

    public void setCity(String City) 
    {
        this.City = City;
    }
    
    
}
